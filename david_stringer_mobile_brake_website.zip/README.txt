DAVID STRINGER MOBILE BRAKE SERVICE — FREE WEBSITE STARTER

FILES
- index.html: ready-to-use, responsive one-page website.
- README.txt: these publishing instructions.

QUICK PREVIEW
1. Open index.html in a web browser to preview the page.
2. To edit wording/prices, open index.html in a text editor and search for the text you want to change.

PUBLISH FOR FREE WITH GITHUB PAGES
1. Create/sign in to a free GitHub account at https://github.com/
2. Create a new public repository named: david-stringer-mobile-brake-service
3. Upload index.html to the repository root (top-level folder).
4. In the repository, open Settings → Pages.
5. Under the build/deployment settings, choose “Deploy from a branch”.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish; the public site address will be shown in Settings → Pages. It commonly looks like:
   https://YOUR-USERNAME.github.io/david-stringer-mobile-brake-service/
   Replace YOUR-USERNAME with your actual GitHub username. Do not print/share that example URL as if it is already live.
8. Open the published link on your phone and test the Call and Text buttons.

ALTERNATIVE
You can use a beginner-friendly visual builder such as Google Sites: https://sites.google.com/
This HTML file is a custom-designed website; visual builders generally require rebuilding the layout in their editor.

BEFORE PUBLISHING
- Confirm that the starting prices are right for your skill, area, vehicle coverage, and business costs.
- Check applicable business licensing, tax, insurance, and mobile-service requirements.
- Consider whether to show a personal number publicly; a separate business line can help protect privacy.
- Do not claim certifications, warranties, insurance, or services you do not actually provide.
- The website does not include a live booking system, payment processing, analytics, or a custom domain.
